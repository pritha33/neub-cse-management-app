export const SECRET_CODES = {
  teacher: "TEACHER2026",
  admin: "ADMIN2026"
};
